#To hide the cursor: printf "\e[?25l"

#To re-enable the cursor: printf "\e[?25h"

printf "\e[?25l"
